import Cocoa

var greeting = "Hola, playground"
var UnaVariable="Test"
let OtraVariable = "Salida"

let lugarNacimiento = "DF"
var ubicacionActual = "Naucalpan"

print(ubicacionActual)

//lugarNacimiento = "cdmx"
/*
 comentarios
 */
ubicacionActual="Xochimilco"
let entero = 15
let flotante = 15.3

var saludo = " "
saludo += "Hola"
saludo += " es "
saludo += " un saludo"
print(saludo)
// anotación explicita de variable

let numero:Int = 12
let palabra:String="Una Palabra"
let numeroFlotante:Double=45.4

//Asinacion de valores

var datoTest:Int = 13
datoTest=15

print(datoTest)


//operadores aritmeticos


var miMarcadorDelOponente = 3*8
var miMarcador = 100/4

//operadores de asignación compuesto
var operadores = 100/4

operadores+=10
operadores-=4
operadores*=2
operadores/=2

//uso del operador modulo

var dividendo = 15
var divisor = 3
var cociente = dividendo/divisor
print(cociente)

















