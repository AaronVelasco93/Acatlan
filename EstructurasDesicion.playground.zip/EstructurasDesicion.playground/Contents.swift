import Cocoa


var enterto:Int=10
var flotante:Float=5.5
var String:String="hola"

if enterto == 10{
        print("el entero es igual  a 10",enterto)
}else{
    print("no es igual a 10")
}


//var greeting = "Hello, playground"

if flotante <= 5.5{
        print("el numero es menor o igual a 5.5")
}else{
    print("el numero es mayor a 5.5")
    
    
    
}



print("----------------------")


let listaMercado=["cebolla","jitomate","aceite","nachos","leche","chile"]


for recorre in listaMercado.sorted(){
    print(recorre)
}
print(listaMercado[3])
print("--------")


for i in 1...10{
    print(i)
}
